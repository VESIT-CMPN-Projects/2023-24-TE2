import cv2
import mediapipe as mp
import numpy as np
from keras.models import load_model
from tensorflow.keras.preprocessing.sequence import pad_sequences
import cv2

model = load_model("trained_21_90.h5")

# fetch classes from gesture.names
classes = []
with open('dynamic.names', 'r') as file:
    classes = file.readlines()
    classes = [c.strip() for c in classes]
    
cap = cv2.VideoCapture("C:\\Users\\piyus\\Downloads\\test.mp4")
coords = mp.solutions.pose
mp_pose = coords.Pose(
    static_image_mode=False,
    model_complexity=2,
    min_detection_confidence=0.5)

mp_drawing = mp.solutions.drawing_utils
mp_drawing_styles = mp.solutions.drawing_styles

predictions = []

while cap.isOpened():
    success, image = cap.read()
    if not success:
        print("Ignoring empty camera frame.")
        break
    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    image.flags.writeable = False
    results = mp_pose.process(image)
    image.flags.writeable = True
    # image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
    try:
        pose = []
        for i, landmark in enumerate(results.pose_landmarks.landmark):
            pose.append([i, landmark.x, landmark.y, landmark.z])
        pose = np.array([pose])
        pose = pad_sequences(pose, padding='post', dtype='float', truncating='post')
        prediction = model.predict(pose)
        class_pred = np.argmax(prediction)
        predictions.append(class_pred)
    except Exception as e:
        print(e)
        pose = None
    
    if results.pose_landmarks:
        mp_drawing.draw_landmarks(
            image, 
            results.pose_landmarks,
            coords.POSE_CONNECTIONS,
            mp_drawing_styles.get_default_pose_landmarks_style(),
        )
            
    cv2.imshow('MediaPipe Pose', image)
    if cv2.waitKey(5) & 0xFF == 27:
        break

print(predictions)
from scipy import stats
final_prediction = stats.mode(predictions)
print(classes[final_prediction[0]])

cap.release()
mp_pose.close()
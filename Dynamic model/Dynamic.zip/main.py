import tensorflow as tf
import numpy as np
from keras.models import load_model
from tensorflow.keras.preprocessing.sequence import pad_sequences
from process_video import process
from gemini import get_sentence

# load model
model = load_model("trained_21_90.h5")

# fetch classes from dynamic.names
with open('dynamic.names', 'r') as file:
    classes = file.readlines()
    classes = [c.strip() for c in classes]

print("\nPlease choose your language: ")
language = input("\n1. English\n2. Hindi")

videos = int(input("\nHow many videos do you want to process? "))
words = []

for i in range(videos):
    video_path = input("\nEnter the path of the video: ")
    processed = process(video_path)
    if processed is not None:
        processed = pad_sequences(processed, padding='post', dtype='float', truncating='post')
        prediction = model.predict(processed)
        class_pred = np.argmax(prediction)
        class_pred = np.array([class_pred])
        words.append(classes[class_pred[0]])

print("\nGenerating sentences...")
sentence = get_sentence(words, language)
print("\nGenerated sentence:", sentence)
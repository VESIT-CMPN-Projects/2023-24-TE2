import os
from gtts import gTTS
from pydub import AudioSegment
from pydub.playback import play
def speak(sentence, language):
    gtts = gTTS(sentence, lang=language)
    gtts.save("temp\\output.mp3")
    def play_sound(file_path):
        try:
            song = AudioSegment.from_mp3(file_path)
            play(song)
        except Exception as e:
            print(f"Error while playing sound: {e}")
    play_sound("temp\\output.mp3")
    os.remove("temp\\output.mp3")
    return

speak("Hello", "en")
